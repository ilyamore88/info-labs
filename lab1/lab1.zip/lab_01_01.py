# однострочный комментарий
'''
Многострочный
комментарий
'''
'''
Пример работы с целыми числами
'''
a = 10
b = 8
print("a = ", a)
print("b = ", b)
print("a + b = ", a + b) # сложение чисел
print("a - b = ", a - b) # вычитание чисел
print("a * b = ", a * b) # умножение чисел
print("a / b = ", a / b) # деление чисел
print("a // b = ", a // b) # деление с округлением вниз до целого
print("a % b = ", a % b) # остаток от деления
print("a ** b = ", a ** b) # возведение в степень
# приведение типа int к float
a1 = float(a)
print("a1 = ",a1)
print("\n\n")
'''
Пример работы с вещественными числами
'''
c = 3.5
d = 6.9
print("c = ", c)
print("d = ", d)
print("c + d = ", c + d) # сложение чисел
print("c * d = ", c * d) # умножение чисел
print("c / d = ", c / d) # деление чисел
d1 = 2.3e-5
print("d1 = ",d1)
print("c + d1 = ", c + d1) # сложение чисел
# приведение типа float к int
d2 = int(d)
print("d2 = ",d2)
print("\n\n")
'''
Операторы присваивания
'''
e = 7
print("e = 7: ", e)
e += 3
print("e += 3: ", e)
e -= 3
print("e -= 3: ", e)
e *= 15
print("e *= 5: ", e)
e /= 4
print("e /= 4: ", e)
e //= 2
print("e //= 2: ", e)
e %= 5
print("e %= 5: ", e)
e **= 3
print("e **= 3: ", e)
print("\n\n")


z = 3
y = 5
print("z + y = ", z + y)
print("z - y = ", z - y)
print("z * y = ", z * y)
print("z / y = ", z / y)
print("z // y = ", z // y)
print("z % y = ", z % y)
print("z ** y = ", z ** y)
print("\n\n")


x = 105
v = 58
print("x / v = ", float(x / v))
print("x / v = ", x / v)